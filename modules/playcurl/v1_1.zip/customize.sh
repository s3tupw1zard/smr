# Error on < Android 8.
if [ "$API" -lt 26 ]; then
    abort "Installing curl"
fi

# curl
mv -f $MODPATH/bin/$ABI/curl $MODPATH
rm -rf $MODPATH/bin
set_perm $MODPATH/curl root root 777